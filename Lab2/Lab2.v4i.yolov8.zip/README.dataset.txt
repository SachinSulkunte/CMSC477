# Lab2 > 2024-03-29 12:37pm
https://universe.roboflow.com/lab2-6txts/lab2-zywuo

Provided by a Roboflow user
License: CC BY 4.0

