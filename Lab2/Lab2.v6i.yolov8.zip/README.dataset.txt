# Lab2 > 2024-04-12 1:00pm
https://universe.roboflow.com/lab2-6txts/lab2-zywuo

Provided by a Roboflow user
License: CC BY 4.0

