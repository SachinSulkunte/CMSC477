# Lab2 > 2024-04-05 1:26pm
https://universe.roboflow.com/lab2-6txts/lab2-zywuo

Provided by a Roboflow user
License: CC BY 4.0

